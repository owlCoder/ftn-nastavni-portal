# Vežba 5 — Integracija modula, ugovori i podaci

Ovaj ZIP je samostalni paket za Vežbu 5. Sadrži ceo `EquipmentReservation.sln` da projekat može odmah da se otvori, builduje i testira.

## Fajlovi na koje je fokus ove vežbe

- `EquipmentReservation.sln`
- `src/Domain/`
- `src/Application/`
- `src/Infrastructure/`
- `src/Api/`
- `src/ConsoleUi/`
- `tests/Tests/Application/CreateReservationHandlerTests.cs`
- `tests/Tests/Integration/ReservationFlowTests.cs`

## Pokretanje

```bash
dotnet restore EquipmentReservation.sln
dotnet build EquipmentReservation.sln --configuration Release
dotnet test EquipmentReservation.sln --configuration Release --no-build
```
