# Vežba 5 — Integracija modula, ugovori i podaci

Ovaj ZIP je samostalni paket za Vežbu 5. Sadrži ceo `EquipmentReservation.sln` da projekat može odmah da se otvori, builduje i testira.

## Fajlovi na koje je fokus ove vežbe

- `EquipmentReservation.sln`
- `src/EquipmentReservation.Domain/`
- `src/EquipmentReservation.Application/`
- `src/EquipmentReservation.Infrastructure/`
- `src/EquipmentReservation.Api/`
- `src/EquipmentReservation.ConsoleUi/`
- `tests/EquipmentReservation.Tests/Application/CreateReservationHandlerTests.cs`
- `tests/EquipmentReservation.Tests/Integration/ReservationFlowTests.cs`

## Pokretanje

```bash
dotnet restore EquipmentReservation.sln
dotnet build EquipmentReservation.sln
dotnet test EquipmentReservation.sln --no-build
```
