# Vežba 8 — Hooks, guardrails i evaluacije

Ovaj ZIP je samostalni paket za Vežbu 8. Sadrži ceo `EquipmentReservation.sln` da projekat može odmah da se otvori, builduje i testira.

## Fajlovi na koje je fokus ove vežbe

- `src/Guardrails/Policies/DangerousCommandGuardrail.cs`
- `src/Guardrails/Policies/SensitiveFileGuardrail.cs`
- `src/Guardrails/Services/GuardrailEvaluator.cs`
- `src/Guardrails/Hosting/GuardrailHook.cs`
- `.vscode/settings.json`
- `.kova/hooks.json`
- `scripts/kova-audit.mjs`
- `evals/review-architecture.json`
- `evals/prompt-injection.json`
- `evals/missing-context.json`
- `tests/Tests/Guardrails/GuardrailPolicyTests.cs`
- `tests/Tests/AiWorkflow/AiWorkflowArtifactsTests.cs`

## Pokretanje

```bash
dotnet restore EquipmentReservation.sln
dotnet build EquipmentReservation.sln --configuration Release
dotnet test EquipmentReservation.sln --configuration Release --no-build
```
