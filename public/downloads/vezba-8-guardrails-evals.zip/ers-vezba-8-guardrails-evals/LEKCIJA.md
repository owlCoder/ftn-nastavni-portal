# Vežba 8 — Hooks, guardrails i evaluacije

Ovaj ZIP je samostalni paket za Vežbu 8. Sadrži ceo `EquipmentReservation.sln` da projekat može odmah da se otvori, builduje i testira.

## Fajlovi na koje je fokus ove vežbe

- `src/EquipmentReservation.Guardrails/Policies/DangerousCommandGuardrail.cs`
- `src/EquipmentReservation.Guardrails/Policies/SensitiveFileGuardrail.cs`
- `src/EquipmentReservation.Guardrails/Services/GuardrailEvaluator.cs`
- `src/EquipmentReservation.Guardrails/Hosting/GuardrailHook.cs`
- `.vscode/settings.json`
- `.kova/hooks.json`
- `scripts/kova-audit.mjs`
- `evals/review-architecture.json`
- `evals/prompt-injection.json`
- `evals/missing-context.json`
- `evals/README.md`
- `tests/EquipmentReservation.Tests/Guardrails/GuardrailPolicyTests.cs`
- `tests/EquipmentReservation.Tests/AiWorkflow/AiWorkflowArtifactsTests.cs`

## Pokretanje

```bash
dotnet restore EquipmentReservation.sln
dotnet build EquipmentReservation.sln
dotnet test EquipmentReservation.sln --no-build
```
