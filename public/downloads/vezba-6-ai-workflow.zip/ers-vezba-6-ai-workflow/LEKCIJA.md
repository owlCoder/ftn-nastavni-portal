# Vežba 6 — Kontrolisan razvoj uz AI

Ovaj ZIP je samostalni paket za Vežbu 6. Sadrži ceo `EquipmentReservation.sln` da projekat može odmah da se otvori, builduje i testira.

## Fajlovi na koje je fokus ove vežbe

- `AGENTS.md`
- `.ai/AI_USAGE.md`
- `.kova/skills/architecture-review/SKILL.md`
- `.kova/skills/implement-approved-plan/SKILL.md`
- `.kova/skills/review-pull-request/SKILL.md`

## Pokretanje

```bash
dotnet restore EquipmentReservation.sln
dotnet build EquipmentReservation.sln
dotnet test EquipmentReservation.sln --no-build
```
