# Vežba 6 — Kontrolisan razvoj uz AI

Ovaj ZIP je samostalni paket za Vežbu 6. Sadrži ceo `EquipmentReservation.sln` da projekat može odmah da se otvori, builduje i testira.

## Fajlovi na koje je fokus ove vežbe

- `.ai/AI_INSTRUCTIONS.md`
- `.ai/AI_USAGE.md`
- `.ai/skills/review-pull-request/SKILL.md`
- `.ai/agents/architecture-reviewer.md`
- `.ai/agents/implementer.md`

## Pokretanje

```bash
dotnet restore EquipmentReservation.sln
dotnet build EquipmentReservation.sln
dotnet test EquipmentReservation.sln --no-build
```
