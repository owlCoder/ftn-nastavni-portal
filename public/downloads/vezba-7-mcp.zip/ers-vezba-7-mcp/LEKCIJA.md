# Vežba 7 — MCP: povezivanje agenata sa projektom

Ovaj ZIP je samostalni paket za Vežbu 7. Sadrži ceo `EquipmentReservation.sln` da projekat može odmah da se otvori, builduje i testira.

## Fajlovi na koje je fokus ove vežbe

- `src/EquipmentReservation.Mcp/Program.cs`
- `src/EquipmentReservation.Mcp/Resources/ProjectResources.cs`
- `src/EquipmentReservation.Mcp/Tools/ProjectTools.cs`
- `src/EquipmentReservation.Mcp/Workspace/ProjectWorkspace.cs`
- `.ai/AI_INSTRUCTIONS.md`

## Pokretanje

```bash
dotnet restore EquipmentReservation.sln
dotnet build EquipmentReservation.sln
dotnet test EquipmentReservation.sln --no-build
```
