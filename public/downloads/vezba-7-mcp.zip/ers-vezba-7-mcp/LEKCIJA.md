# Vežba 7 — MCP: povezivanje agenata sa projektom

Ovaj ZIP je samostalni paket za Vežbu 7. Sadrži ceo `EquipmentReservation.sln` da projekat može odmah da se otvori, builduje i testira.

## Fajlovi na koje je fokus ove vežbe

- `src/Mcp/Program.cs`
- `src/Mcp/Resources/ProjectResources.cs`
- `src/Mcp/Tools/ProjectTools.cs`
- `src/Mcp/Workspace/ProjectPathPolicy.cs`
- `src/Mcp/Models/ProjectCommand.cs`
- `.kova/mcp.json`

## Pokretanje

```bash
dotnet restore EquipmentReservation.sln
dotnet build EquipmentReservation.sln --configuration Release
dotnet test EquipmentReservation.sln --configuration Release --no-build
```
